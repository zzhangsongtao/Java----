import java.util.List;
import java.util.Stack;

class Calculator {
    public double calculate(Stack<String> array) {
        Stack<String> numStack = new Stack<String>();
        //正序遍历后缀表达式数组
        while (!array.isEmpty()) {
            String item = array.pop();
            if (Converter.isSymbol(item)) {//遍历到运算符，顺序在栈中取出两个数，然后逆向让两个数运算，将运算的结果入栈
                double result = 0;
                double num1 = Double.parseDouble(numStack.pop());
                double num2 = Double.parseDouble(numStack.pop());
                if (item.equals("+")) {
                    result = num2 + num1;
                } else if (item.equals("-")) {
                    result = num2 - num1;
                } else if (item.equals("*")) {
                    result = num2 * num1;
                } else if (item.equals("/")) {
                    result = num2 / num1;
                }
                numStack.push(String.valueOf(result));
            } else {//遍历到数字，直接入栈
                numStack.push(item);
            }
        }
        //最后出栈的就是计算的结果
        return Double.parseDouble(numStack.pop());
    }
}